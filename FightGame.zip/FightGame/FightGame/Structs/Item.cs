namespace FightGame.Structs
{
    public struct Item
    {
        private string _name;
        private int _cost;
        private int _protection;
        private int _protectionQuality;
        private ItemType _type;
        private ItemSize _size;

        public string Name => _name;
        public int Cost => _cost;
        public int Protection
        {
            get => _protection;
            set => _protection = value;
        }

        public int ProtectionQuality
        {
            get => _protectionQuality;
            set => _protectionQuality = value;
        }
        public ItemType Type => _type;
        public ItemSize Size => _size;

        public Item(string name, int cost, int protection, int protectionQuality, ItemType type, ItemSize size)
        {
            _name = name;
            _cost = cost;
            _protection = protection;
            _protectionQuality = protectionQuality;
            _type = type;
            _size = size;
        }

        public static Item GenerateItem(string name, int maxCost, int maxProtection, int maxProtectionQuality)
        {
            Random random = new();

            return new Item(name,                                                  //Имя
                random.Next(0, maxCost),                                           //Цена
                random.Next(0, maxProtection),                                     //Защита
                random.Next(0, maxProtectionQuality),                              //Качесво защиты
                (ItemType)random.Next(0, Enum.GetNames(typeof(ItemSize)).Length),  //Тип
                (ItemSize)random.Next(0, Enum.GetNames(typeof(ItemSize)).Length)); //Размер
        }

        public void PrintItemInfo()
        {
            Console.WriteLine("Имя " + _name);
            Console.WriteLine("Стоимотсь " + _cost);
            Console.WriteLine("Защита " + _protection);
            Console.WriteLine("Качество защиты " + _protectionQuality);
            Console.WriteLine("Размер " + _size);
            Console.WriteLine("Тип " + _type);
            Console.WriteLine();
        }
    }

    public enum ItemType
    {
        Weapon,
        Shield,
        Accessories
    }

    public enum ItemSize
    {
        Small,
        Medium,
        Large
    }
}