using FightGame.Interfaces;
using FightGame.Structs;

namespace FightGame.Scripts
{
    public class Player : IBattler
    {
        public const int MinHealth = 1;
        public readonly int MaxHealth;

        private string _name;
        private int _lifes;
        private CharacterParams _params;

        private int _gold;
        private Inventory _inventory;
        private Equipment _equipment;
        private int _highestHealth;

        public int PosX;
        public int PosY;
        public int LastPosX;
        public int LastPosY;

        public int Lifes => _lifes;
        public CharacterParams Params => _params;
        public Inventory Inventory
        {
            get => _inventory;
        }
        public int Gold
        {
            get { return _gold; }
            set
            {
                _gold = value;
            }
        }
        public Equipment Equipment => _equipment;
        public int HighestHealth => _highestHealth;
        public string Name => _name;
        public int Protection => _inventory.TotalProtection;
        public int ProtectionQuality => _inventory.TotalProtectionQuality;

        public Player(string name)
        {
            _name = name;
            _params = new CharacterParams(name, 200, 50, 20);
            _inventory = new(new Item("TestItemForPlayer", 0, 0, 0, ItemType.Shield, ItemSize.Small));
            _lifes = 3;
            _gold = 100;
            _equipment = new Equipment(4, 2, 1);
            MaxHealth = 500;
            _highestHealth = _params.Health;
        }

        public void TakeDmg(int damage)
        {
            if (_inventory.TotalProtection > 0)
            {
                _inventory.TotalProtection -= damage * _inventory.TotalProtectionQuality / 100;
                damage -= damage * _inventory.TotalProtectionQuality / 100;
                if (_inventory.TotalProtectionQuality < 0)
                    damage += _inventory.TotalProtectionQuality * -1;
            }

            _params.Health -= damage;
        }

        public void Respawn()
        {
            if (_params.Health <= 0)
            {
                if (_lifes > 0)
                {
                    _lifes -= 1;
                    Console.WriteLine($"У игрока осталось {_lifes} жизней");
                    _params.Health = _highestHealth;
                }
                else
                {
                    Console.WriteLine("У игрока не осталось жизней");
                }
            }
            else
            {
                Console.WriteLine("Игрок еще жив");
            }
        }

        public void Regeneration()
        {
            if (_params.Health < MaxHealth)
            {
                _params.Health += 50;

                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Восстановлено 5 здоровья");
                Console.WriteLine($"Ваше здоровье {_params.Health}");
                Console.ForegroundColor = ConsoleColor.White;

                _highestHealth = _params.Health;
            }
        }

        public void PrintStats()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"Ваши характеристики");
            Console.WriteLine($"Имя: {Name}, Здоровье: {_params.Health}, Урон: {_params.Damage}, " +
                $"Защита {_inventory.TotalProtection}, Качество защиты {_inventory.TotalProtectionQuality}, " +
                $"Шанс промаха: {_params.MissChance}%");

            Console.ForegroundColor = ConsoleColor.White;
        }
    }
}